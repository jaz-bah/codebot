//jquery for video modal
function openVideoModal(link){
    $('#videoItem').removeAttr('src');
    $('#videoItem').attr('src', link);
}

// details page share modal copy jquery
function copyToClipBoard(id) {
    navigator.clipboard.writeText(document.getElementById(id).value);
}

$(document).ready(()=>{

//jquery for password box on login modal
$('#passwordView').click(()=>{
    let inputType = $('#passwordBox').attr('type');
    $('#passwordView').toggleClass('bx-hide');
    $('#passwordView').toggleClass('bx-show');

    if(inputType === "text"){
        $('#passwordBox').attr('type', 'password');
    } else {
        $('#passwordBox').attr('type', 'text');
    }
    
})

//jquery for home page sticky navbar 
$(window).scroll(() => {
    if(this.scrollY > 0){
        $('.home_nav').addClass('position_fixed');
    } else if (this.scrollY == 0) {
        $('.home_nav').removeClass('position_fixed');
    }
})

//select2 for home page
$("#typeSelector").select2({
    placeholder: "All Categories",
    allowClear: true,
    minimumResultsForSearch: -1,
});
$("#placeSelector").select2({
    placeholder: "All Location",
    allowClear: true,
    minimumResultsForSearch: -1,
});

//bootstrap tooltip
$(function () {
    $('[data-toggle="tooltip"]').tooltip()
})


//jquery for details page sticky navbar
$(window).scroll(() => {
    if(this.scrollY > 0){
        $('.detail_page_nav').addClass('position_fixed');
    } else if (this.scrollY == 0) {
        $('.detail_page_nav').removeClass('position_fixed');
    }
})


//listing page js
$(".filter_btn").click(function(){
    $(".filter_menu").toggleClass('d-none');
    $(".filter_menu").toggleClass('d-block');
});

$(".close_btn").click(function(){
    $(".filter_menu").removeClass('d-block');
    $(".filter_menu").addClass('d-none');
});

$('.ham').click(()=>{
    $('.ham').toggleClass('active')
});
$('.close_canvas').click(()=>{
    $('.ham').removeClass('active')
    $('.hamburger__icon').removeClass('active')
});
$('.hamburger__button').click(()=>{
    $('.hamburger__icon').toggleClass('active')
});


$('#nearMeHeading').click(()=>{
    $('.check_km').toggleClass('d-none');
});

$('.category_header').click(()=>{
    $('.cetegory_icon').toggleClass('active');
});
$('.location_header').click(()=>{
    $('.location_icon').toggleClass('active');
});

$("#menu-toggle").click(function(e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
});


// top menu select2 listing page
$(".listingPageTypeSelector").select2({
    placeholder: "All Categories",
    allowClear: true,
    minimumResultsForSearch: -1,
});
$(".listingPagePlaceSelector").select2({
    placeholder: "All Location",
    allowClear: true,
    minimumResultsForSearch: -1,
});


//range input
$('#inputRange').on('input', function () {
    var slider = $(this).val();
    var maxval = $(this).attr('max');
    var val = (slider/ maxval) * 100;
    $('.progress').css({"width": val+'%'});
    $('.slider_thumb').css({"left": val+'%'});
    $('.selected_distance').text(slider)
});

$('#inputRangePopup').on('input', function () {
    var slider = $(this).val();
    var maxval = $(this).attr('max');
    var val = (slider/ maxval) * 100;
    $('.slider_thumb').css({"left": val+'%'});
    $('.selected_distance').text(slider+'km')
});



$(document).on('hidden.bs.offcanvas', '.listing_page_left_canvas', function (e) {
    $('.ham').removeClass('active')
    $('.hamburger__icon').removeClass('active')
});


//listing page tabs
$('.map_btn').click(()=>{
    $('.list_btn').removeAttr('style');
    $('.map_btn').css('background-color','#f8f8f8');
    $('.listing_page_card').addClass('d-none');
    $('.listing_page_map').removeClass('d-none');
})
$('.list_btn').click(()=>{
    $('.map_btn').removeAttr('style');
    $('.list_btn').css('background-color','#f8f8f8');
    $('.listing_page_map').addClass('d-none');
    $('.listing_page_card').removeClass('d-none');
})


//filter menu popup
$('.address_input').click(()=>{
    $('.popup_adress_box').addClass('popup_adress_box_acive');
})
$('.close_adress_popup').click(()=>{
    $('.popup_adress_box').removeClass('popup_adress_box_acive');
})

$('#switchAdress').click(()=>{
    $('.address_input').toggleClass('d-none')
    $('.select_box').toggleClass('d-none')
})

//listing page distance type checker

$('#checkDistanceType').change((e)=>{
    if(e.target.checked){
        $('.distance_type').text('mile');
    } else {
        $('.distance_type').text('km');
    }
})


});



