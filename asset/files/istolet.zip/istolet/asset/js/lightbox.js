//home page gellary
lightGallery(document.getElementById('lightgallery-one'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
});
lightGallery(document.getElementById('lightgallery-tow'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
});
lightGallery(document.getElementById('lightgallery-three'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
});
lightGallery(document.getElementById('lightgallery-four'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
});
lightGallery(document.getElementById('lightgallery-five'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
});
lightGallery(document.getElementById('lightgallery-six'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
});

function openLightbox(item){
  $(`#${item}`).trigger("click");
}



//details page gellary
lightGallery(document.getElementById('details-lightgallery-one'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
});


//vedio detail page gellery
lightGallery(document.getElementById('detailsVideo-lightgallery-one'), {
    plugins: [lgAutoplay, lgFullscreen, lgZoom, lgShare, lgRotate, lgThumbnail],
    speed: 500,
    selector: '.include-in-gallery',
});

