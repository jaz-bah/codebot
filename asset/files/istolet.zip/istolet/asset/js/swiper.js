
//home page swiper
var swiper = new Swiper(".bannerSwiper", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
    },
    navigation: {
        nextEl: '.bannerSwiper-next',
        prevEl: '.bannerSwiper-prev',
    },
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
    breakpoints: {
        540: {
          slidesPerView: 2,
          spaceBetween: 5,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 10,
        },
        1024: {
          slidesPerView: 5,
          spaceBetween: 30,
        },
    },
});


var swiper = new Swiper(".sponserSwiper", {
  slidesPerView: 1,
  spaceBetween: 0,
  loop: true,
  navigation: {
      nextEl: '.sponserSwiper-next',
      prevEl: '.sponserSwiper-prev',
  },
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
  },
  breakpoints: {
      768: {
        slidesPerView: 2,
        spaceBetween: 10,
      },
      1024: {
        slidesPerView: 3,
        spaceBetween: 30,
      },
  },
});


//details page swiper
var swiper = new Swiper(".singelSponserSwiper", {
slidesPerView: 1,
loop: true,
navigation: {
    nextEl: '.singelSponserSwiper-next',
    prevEl: '.singelSponserSwiper-prev',
},
autoplay: {
  delay: 5000,
  disableOnInteraction: false,
},
});


//listing page swiper

var swiper = new Swiper(".listingSwiper", {
  slidesPerView: 1,
  spaceBetween: 0,
  loop: true,
  navigation: {
      nextEl: '.listingSwiper-next',
      prevEl: '.listingSwiper-prev',
  },
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
  },
  breakpoints: {
      1000: {
        slidesPerView: 3,
        spaceBetween: 30,
      },
      1400: {
        slidesPerView: 4,
        spaceBetween: 30,
      },
  },
});