window.onload = function (){
    let City = 'Dhaka';

    date();
    getData(City);
    handleLocations(City);
}