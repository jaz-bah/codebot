window.onload = function (){
    getData()
}

function getData(){
    $.get('https://pizza.jahangirpial.com/wp-json', function(data){

        let title = data.name;
        $('#siteTitle').text(title)

        console.log(title)

    })

    $.get('https://pizza.jahangirpial.com/wp-json/wp/v2/media', function(data){
        let source = data[0].source_url;
        $('#navLogo').attr('src',source);

        console.log(source)
    })

    $.get('https://pizza.jahangirpial.com/wp-json/wp/v2/posts', function(data){
        let itme1 = data[0].title.rendered ;
        $('#item1').text(itme1);

        let itme2 = data[1].title.rendered ;
        $('#item2').text(itme2);

        let itme3 = data[2].title.rendered ;
        $('#item3').text(itme3);

        let itme4 = data[3].title.rendered ;
        $('#item4').text(itme4);
    })
}