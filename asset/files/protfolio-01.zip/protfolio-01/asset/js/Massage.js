function submitMassage(){
    let name = $("#massageName").val();
    let subject = $("#massageSubject").val();
    let massage = $("#Massage").val();

    if (name == ""){
        alert("Please input your name");
    } else if (subject == ""){
        alert("Please input your subject");
    } else if (massage == ""){
        alert("Please input your massage");
    } else {
        alert("Thank's for your valuable words");

        $("#massageName").val("");
        $("#massageSubject").val("");
        $("#Massage").val("");
    }
}