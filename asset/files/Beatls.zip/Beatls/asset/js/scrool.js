var section = $('.section-');

section.waypoint(function(){

    $('.section-').toggleClass('');

},
{
    offset: '-1%'
})
